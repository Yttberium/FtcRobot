package org.firstinspires.ftc.teamcode.teamcode.Subsystems;

public class PID {
    public static double kP = 0.0004;
    public static double kD = 0.0001;
    public static double kI = 0.0001;
}
